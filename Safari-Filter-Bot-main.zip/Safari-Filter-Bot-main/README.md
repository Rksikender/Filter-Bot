<p align="center">
  <img src="https://graph.org/file/07038c2e2f6211fc132c0.jpg" alt="Safari-Filter-Bot Logo">
</p>
<h1 align="center">
  𝑺𝒂𝒇𝒂𝒓𝒊-𝑭𝒊𝒍𝒕𝒆𝒓-𝑩𝒐𝒕
</h1>

![Typing SVG](https://readme-typing-svg.herokuapp.com/?lines=𝑊𝑒𝑙𝑐𝑜𝑚𝑒+𝑆𝑎𝑓𝑎𝑟𝑖-𝐹𝑖𝑙𝑡𝑒𝑟-𝐵𝑜𝑡!;𝐶𝑟𝑒𝑎𝑡𝑒𝑑+𝑏𝑦+𝑆𝑎𝑓𝑎𝑟𝑖𝑑𝑒𝑣𝑣!;𝐴+𝑝𝑜𝑤𝑒𝑟𝑓𝑢𝑙+⚡+𝑠𝑢𝑝𝑒𝑟+𝑎𝑛𝑑+𝑐𝑜𝑜𝑙+𝑓𝑒𝑎𝑡𝑢𝑟𝑒𝑠+𝑠𝑒𝑒+𝑡ℎ𝑒+𝑓𝑒𝑎𝑡𝑢𝑟𝑒𝑠!)
</p>
## 𝐹𝑒𝑎𝑡𝑢𝑟𝑒𝑠
♦ 𝐼𝑀𝐷𝐵 𝑇𝑒𝑚𝑝𝑙𝑎𝑡𝑒 𝑆𝑒𝑡
♦ 𝑃𝑟𝑒𝐷𝑉𝐷 𝑎𝑛𝑑 𝐶𝑎𝑚𝑅𝑖𝑝 𝐷𝑒𝑙𝑒𝑡𝑒 𝑀𝑜𝑑𝑒
♦ 𝑀𝑢𝑙𝑡𝑖𝑝𝑙𝑒 𝐹𝑖𝑙𝑒 𝐷𝑒𝑙𝑒𝑡𝑖𝑜𝑛
♦ 𝑆𝑒𝑡𝑡𝑖𝑛𝑔𝑠 𝑀𝑒𝑛𝑢
♦ 𝐹𝑜𝑟𝑐𝑒 𝑆𝑢𝑏𝑠𝑐𝑟𝑖𝑝𝑡𝑖𝑜𝑛
♦ 𝑊𝑒𝑙𝑐𝑜𝑚𝑒 𝑀𝑒𝑠𝑠𝑎𝑔𝑒
♦ 𝐴𝑢𝑡𝑜𝑚𝑎𝑡𝑖𝑐 𝐹𝑖𝑙𝑒 𝐹𝑖𝑙𝑡𝑒𝑟𝑖𝑛𝑔
♦ 𝑇𝑒𝑥𝑡 𝑜𝑟 𝐵𝑢𝑡𝑡𝑜𝑛 𝐹𝑖𝑙𝑡𝑒𝑟
♦ 𝐼𝑀𝐷𝐵
♦ 𝐴𝑑𝑚𝑖𝑛 𝐶𝑜𝑚𝑚𝑎𝑛𝑑𝑠
♦ 𝑈𝑠𝑒𝑟 𝐵𝑟𝑜𝑎𝑑𝑐𝑎𝑠𝑡
♦ 𝐺𝑟𝑜𝑢𝑝 𝐵𝑟𝑜𝑎𝑑𝑐𝑎𝑠𝑡
♦ 𝐼𝑀𝐷𝐵 𝑠𝑒𝑎𝑟𝑐ℎ
♦ 𝑅𝑎𝑛𝑑𝑜𝑚 𝑝𝑖𝑐𝑠
♦ 𝑖𝑑𝑠 𝑎𝑛𝑑 𝑈𝑠𝑒𝑟 𝑖𝑛𝑓𝑜 
♦ 𝑆𝑡𝑎𝑡𝑠
♦ 𝑈𝑠𝑒𝑟𝑠
♦ 𝐶ℎ𝑎𝑡𝑠
♦ 𝑈𝑠𝑒𝑟 𝐵𝑎𝑛
♦ 𝑈𝑠𝑒𝑟 𝑈𝑛𝑏𝑎𝑛
♦ 𝐶ℎ𝑎𝑡 𝐿𝑒𝑎𝑣𝑒
♦ 𝐶ℎ𝑎𝑡 𝐷𝑖𝑠𝑎𝑏𝑙𝑒
♦ 𝐶ℎ𝑎𝑛𝑛𝑒𝑙
♦ 𝑆𝑝𝑒𝑙𝑙𝑖𝑛𝑔 𝐶ℎ𝑒𝑐𝑘 𝐹𝑒𝑎𝑡𝑢𝑟𝑒
♦ 𝐴𝑢𝑡𝑜 𝐷𝑒𝑙𝑒𝑡𝑒
╔═══════ 𝑬𝒙𝒕𝒓𝒂 𝑨𝒅𝒅𝒆𝒅 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔 ═══════╗

🔷 𝑮𝒓𝒐𝒖𝒑 𝑽𝒆𝒓𝒊𝒇𝒚 𝑺𝒚𝒔𝒕𝒆𝒎
🔷 𝑺𝒕𝒓𝒆𝒂𝒎𝒊𝒏𝒈 𝑺𝒉𝒐𝒓𝒏𝒆𝒓 𝑳𝒊𝒏𝒌
🔷 𝑨𝒊 𝑺𝒑𝒆𝒍𝒍 𝑪𝒉𝒆𝒄𝒌
🔷 𝑪𝒉𝒂𝒏𝒏𝒆𝒍 𝑻𝒂𝒈 𝑹𝒆𝒎𝒐𝒗𝒆
🔷 𝑭𝒖𝒍𝒍 𝑪𝒖𝒔𝒕𝒐𝒎𝒊𝒛𝒃𝒍𝒆 𝑩𝒐𝒕 𝑰𝒏 𝑮𝒓𝒐𝒖𝒑
🔷 𝑨𝒅𝒅 𝑷𝒓𝒆𝒎𝒊𝒖𝒎 𝑼𝒔𝒆𝒓𝒔 𝑰𝒏 𝑪𝒐𝒎𝒎𝒂𝒏𝒅
🔷 𝑹𝒆𝒎𝒐𝒗𝒆 𝑼𝒏𝒔𝒆𝒂𝒔𝒆𝒚 𝑼𝒔𝒆𝒍𝒆𝒔𝒔 𝑾𝒐𝒓𝒅
🔷 𝑨𝒏𝒅 𝑮𝒓𝒐𝒖𝒑 𝑪𝒐𝒏𝒕𝒓𝒐𝒍 𝑭𝒆𝒂𝒕𝒖𝒓𝒆𝒔

<b>𝙅𝙤𝙞𝙣 𝘽𝙤𝙩 𝙐𝙥𝙙𝙖𝙩𝙚𝙨 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 <a href='https://telegram.me/SafariBotts'>𝐁𝐨𝐭 𝐔𝐩𝐝𝐚𝐭𝐞 𝐈𝐧𝐟𝐨𝐫𝐦𝐚𝐭𝐢𝐨𝐧</a>.</b>

## 𝐶𝑜𝑚𝑚𝑎𝑛𝑑𝑠

## Variables

### Required Variables
* `BOT_TOKEN`: Create a bot using [@BotFather](https://telegram.dog/BotFather), and get the Telegram API token.
* `API_ID`: Get this value from [telegram.org](https://my.telegram.org/apps)
* `API_HASH`: Get this value from [telegram.org](https://my.telegram.org/apps)
* `CHANNELS`: Username or ID of channel or group. Separate multiple IDs by space
* `ADMINS`: Username or ID of Admin. Separate multiple Admins by space
* `DATABASE_URI`: [mongoDB](https://www.mongodb.com) URI. Get this value from [mongoDB](https://www.mongodb.com). For more help watch this [video](https://youtu.be/1G1XwEOnxxo)
* `DATABASE_NAME`: Name of the database in [mongoDB](https://www.mongodb.com). For more help watch this [video](https://youtu.be/1G1XwEOnxxo)
* `LOG_CHANNEL` : A channel to log the activities of bot. Make sure bot is an admin in the channel.
* `FQDN` : Online Streaming: fill app server link without [https://] & [/] 
* `BIN_CHANNEL` : Streaming stats


<details><summary>Deploy To Heroku</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/Safaridevv/SuperBot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy To Heroku">
</a>
</p>
</details>
<details><summary>Deploy To Heroku Via Bot</summary>
<p>
<br>
<a href="https://telegram.dog/XTZ_HerokuBot?start=Sm9lbGtiL0RRLXRoZS1maWxlLWRvbm9yIG1hc3Rlcg">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy Via Heroku Bot">
</a>
</p>
</details>

<details><summary>Deploy To Koyeb</summary>
<br>
<b>The fastest way to deploy the application is to click the Deploy to Koyeb button below.</b>
<br>
<br>

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/Safaridevv/SuperBot&branch=main)
</details>

<details><summary>Deploy To Render</summary>
<br>
<b>
Use these commands:
<br>
<br>
• Build Command: <code>pip3 install -U -r requirements.txt</code>
<br>
<br>
• Start Command: <code>python3 bot.py</code>
<br>
<br>
Go to https://uptimerobot.com/ and add a monitor to keep your bot alive.
<br>
<br>
Use these settings when adding a monitor:</b>
<br>
<br>
<img src="https://telegra.ph/file/a79a156e44f43c9833b50.jpg" alt="render template">
<br>
<br>
<b>Click on the below button to deploy directly to render ↓</b>
<br>
<br>
<a href="https://render.com/deploy?repo=https://github.com/Safaridevv/SuperBot">
<img src="https://render.com/images/deploy-to-render-button.svg" alt="Deploy to Render">
</a>
</details>

<details><summary>Deploy To VPS</summary>
<p>
<pre>
git clone https://github.com/Joelkb/DQ-The-File-Donor
# Install Packages
pip3 install -U -r requirements.txt
Edit info.py with variables as given below then run bot
python3 bot.py
</pre>
</p>
</details>

<hr>
